<?php

/**
 * Partial of the event discovery widget
 *
 * @link       http://www.ticketmaster.com
 * @since      1.0.0
 *
 * @package    Ticketmaster
 * @subpackage Ticketmaster/admin/partials
 */

?>

<div id="ticketmaster-settings" class="wrap">
	<h2><?php esc_attr_e( 'Ticketmaster Settings', $this->plugin_name ); ?></h2>
	<?php
	require_once( 'ticketmaster-admin-nav-tab.php' );
	?>
	<div class="wrap ticketmaster-metaboxes">
		<div id="event-discovery-config">
			<h2><?php esc_attr_e( 'Event Discovery Widget', $this->plugin_name ); ?></h2>
			<p><?php esc_attr_e( 'You can use the widget configurator below to customize the layout of the widget.', $this->plugin_name ); ?></p>
			<div class="row row-native">
				<div class="col-lg-4 config-block">
	
						<form accept-charset="UTF-8" class="main-widget-config-form common_tabs" method="post" autocomplete="off">
	
		                <!--Use for mobile devices 'Go' button-->
						<button type="submit" class="hidden"></button>
	
						<div>
							<label for="w-title"><?php esc_attr_e( 'Title', $this->plugin_name ); ?> <span class="config_field__description"><?php esc_attr_e( '(Required)', $this->plugin_name ); ?></span></label>
							<input type="text" id="w-title" name="w-title" maxlength="255">
						</div>
	
		                <ul class="nav nav-tabs" data-tabs="tabs">
							<li class="active">
								<a href="#widget-config-setup" data-toggle="tab"><?php esc_attr_e( 'Technical', $this->plugin_name ); ?></a>
							</li>
		                    <li>
		                        <a id="js_styling_nav_tab" href="#widget-config-styling" data-toggle="tab"><?php esc_attr_e( 'Visual', $this->plugin_name ); ?></a>
		                    </li>
		                </ul>
	
		                <div class="tab-content">
		                    <div class="tab-pane fade in active" id="widget-config-setup">
		                        <div class="row row-native">
		                            <div class="col-lg-12 col-md-6 col-sm-6">
		                                <div class="widget_api_key">
		                                    <label for="w-tm-api-key">
												<?php esc_attr_e( 'API Key', $this->plugin_name ); ?> <span class="config_field__description"><?php esc_attr_e( '(Required)', $this->plugin_name ); ?></span>
		                                    </label>
		                                    <a href="https://developer-acct.ticketmaster.com/user/login" class="pull-right"><?php esc_attr_e( 'Get your own', $this->plugin_name ); ?></a>
		                                    <div class="widget_api_key__field">
		                                        <input type="text" id="w-tm-api-key" name="w-tm-api-key" value="5QGCEXAsJowiCI4n1uAwMlCGAcSNAEmG">
		                                        <a href="http://developer.ticketmaster.com/support/faq/" class="widget_api_key__question"></a>
		                                    </div>
		                                </div>
		                            </div>
		                            <div class="col-lg-12 col-md-6 col-sm-6">
		                                <label for="w-keyword"><?php esc_attr_e( 'Keyword', $this->plugin_name ); ?></label>
		                                <input type="text" id="w-keyword" name="w-keyword" value="">
		                            </div>
		                        </div>
	
		                        <div class="row row-native">
		                            <div class="col-lg-12 base-margin-bottom">
		                                <label>Period</label>
		                                <div class="row radio-buttons">
		                                    <div class="col-lg-3 col-sm-2 col-xs-6 widget__various-min-width">
		                                        <input checked="" id="w-period-day" type="radio" value="day" name="w-period">
		                                        <label for="w-period-day"><?php esc_attr_e( 'Today', $this->plugin_name ); ?></label>
		                                    </div>
		                                    <div class="col-lg-3 col-sm-2 col-xs-6 widget__various-min-width">
		                                        <input checked="" id="w-period-week" type="radio" value="week" name="w-period">
		                                        <label for="w-period-week"><?php esc_attr_e( 'Week', $this->plugin_name ); ?></label>
		                                    </div>
		                                    <div class="col-lg-3 col-sm-2 col-xs-6 widget__various-min-width">
		                                        <input id="w-period-month" type="radio" value="month" name="w-period">
		                                        <label for="w-period-month"><?php esc_attr_e( 'Month', $this->plugin_name ); ?></label>
		                                    </div>
		                                    <div class="col-lg-3 col-sm-2 col-xs-6 widget__various-min-width">
		                                        <input id="w-period-year" type="radio" value="year" name="w-period">
		                                        <label for="w-period-year"><?php esc_attr_e( 'Year', $this->plugin_name ); ?></label>
		                                    </div>
		                                </div>
		                            </div>
		                        </div>
	
		                        <div class="row row-native">
		                            <div class="col-lg-6 col-md-6 col-sm-3">
		                                <label for="w-postalcode"><?php esc_attr_e( 'ZIP Code', $this->plugin_name ); ?></label>
		                                <input type="text" id="w-postalcode" name="w-postalcode" value="90015">
		                            </div>
		                            <div class="col-lg-6 col-md-6 col-sm-3">
		                                <label for="w-radius">
			                                <?php esc_attr_e( 'Radius', $this->plugin_name ); ?> <span class="config_field__description"><?php esc_attr_e( '(miles)', $this->plugin_name ); ?></span>
		                                </label>
		                                <input class="js_widget__number js_numeric_input text-center" type="number" id="w-radius" name="w-radius" value="25">
		                            </div>
		                        </div>
		                        <div class="row row-native">
		                            <div class="col-lg-12 col-md-12 col-sm-6">
		                                <label for="w-country"><?php esc_attr_e( 'Country', $this->plugin_name ); ?></label>
		                            </div>
		                            <div class="col-xs-12 country-select">
		                                <div class="js_custom_select custom_select">
		                                    <select id="w-country" class="custom_select__field" name="w-country">
		                                        <option selected="" value="US"><?php esc_attr_e( 'United States', $this->plugin_name ); ?></option>
		                                    </select>
		                                    <input class="custom_select__placeholder" type="text" value="United States" readonly="">
		                                    <ul class="custom_select__list js_widget_custom__list">
		                                        <li class="custom_select__item custom_select__item-active" data-value="US"><?php esc_attr_e( 'United States', $this->plugin_name ); ?></li>
		                                    </ul>
		                                    <div class="custom_select__arrow"></div></div>
		                            </div>
		                        </div>
	
		                        <div class="row row-native">
		                            <div class="col-lg-6 col-md-6 col-sm-3">
		                                <label for="w-attractionid"><?php esc_attr_e( 'Attraction ID', $this->plugin_name ); ?></label>
		                                <input type="text" id="w-attractionid" name="w-attractionid" value="">
		                            </div>
		                            <div class="col-lg-6 col-md-6 col-sm-3">
		                                <label for="w-promoterid"><?php esc_attr_e( 'Promoter ID', $this->plugin_name ); ?></label>
		                                <input type="text" id="w-promoterid" name="w-promoterid" value="">
		                            </div>
		                            <div class="col-lg-6 col-md-6 col-sm-3">
		                                <label for="w-venueid"><?php esc_attr_e( 'Venue ID', $this->plugin_name ); ?></label>
		                                <input type="text" id="w-venueid" name="w-venueid" value="">
		                            </div>
		                            <div class="col-lg-6 col-md-6 col-sm-3">
		                                <label for="w-city"><?php esc_attr_e( 'City', $this->plugin_name ); ?></label>
		                                <input type="text" id="w-city" name="w-city" value="">
		                            </div>
		                            <div class="col-lg-6 col-md-6 col-sm-3">
		                                <label for="w-countryCode"><?php esc_attr_e( 'Country Code', $this->plugin_name ); ?></label>
		                                <input type="text" id="w-countryCode" name="w-countryCode" value="">
		                            </div>
		                            <div class="col-lg-6 col-md-6 col-sm-3">
		                                <label for="w-source"><?php esc_attr_e( 'Source', $this->plugin_name ); ?></label>
		                                <input type="text" id="w-source" name="w-source" value="">
		                            </div>
		                            <div class="col-lg-12 col-md-6 col-sm-3">
		                                <label for="w-classificationname"><?php esc_attr_e( 'Classification Name', $this->plugin_name ); ?></label>
		                                <input type="text" id="w-classificationname" name="w-classificationname" value="">
		                            </div>
		                        </div>
	
		                        <div class="row row-native">
		                            <div class="col-lg-12 col-md-6 col-sm-6">
		                                <label for="w-affiliateid"><?php esc_attr_e( 'Affiliate ID', $this->plugin_name ); ?></label>
		                                <input type="text" id="w-affiliateid" name="w-affiliateid" value="">
		                            </div>
		                            <div class="col-lg-12 col-md-6 col-sm-6">
		                                <label for="w-size">
			                                <?php esc_attr_e( 'Event Count', $this->plugin_name ); ?> <span class="config_field__description">(1-100)</span>
		                                </label>
		                            </div>
		                            <div class="col-lg-3 col-md-2 col-sm-2 widget__various-width">
		                                <input class="js_widget__number js_numeric_input text-center double-margin-bottom" type="number" id="w-size" name="w-size" value="25" required="">
		                            </div>
		                        </div>
		                    </div>
	
		                    <div class="tab-pane fade" id="widget-config-styling">
		                        <div class="row row-native">
		                            <div class="col-lg-12 col-md-12 col-sm-12 col-sm-theme">
		                                <label><?php esc_attr_e( 'Themes', $this->plugin_name ); ?></label>
		                                <div class="tab-buttons">
		                                    <input checked="" id="w-theme-simple" type="radio" value="simple" name="w-theme">
		                                    <label for="w-theme-simple"><?php esc_attr_e( 'Poster', $this->plugin_name ); ?></label>
		                                    <input id="w-theme-oldschool" type="radio" value="oldschool" name="w-theme">
		                                    <label for="w-theme-oldschool"><?php esc_attr_e( 'Oldskool', $this->plugin_name ); ?></label>
		                                    <input id="w-theme-newschool" type="radio" value="newschool" name="w-theme">
		                                    <label for="w-theme-newschool"><?php esc_attr_e( 'Color Block', $this->plugin_name ); ?></label>
		                                    <input id="w-theme-listview" type="radio" value="listview" name="w-theme">
		                                    <label for="w-theme-listview"><?php esc_attr_e( 'List View', $this->plugin_name ); ?></label>
		                                </div>
		                            </div>
	
		                            <div class="col-lg-12 col-md-12 col-sm-12 col-sm-color_scheme">
		                                <div class="widget__color_scheme_control" style="display: none">
		                                    <label><?php esc_attr_e( 'Color Scheme', $this->plugin_name ); ?></label>
		                                    <div class="tab-buttons">
		                                        <input checked="" id="w-colorscheme-light" type="radio" value="light" name="w-colorscheme">
		                                        <label for="w-colorscheme-light"><?php esc_attr_e( 'Light', $this->plugin_name ); ?></label>
		                                        <input id="w-colorscheme-dark" type="radio" value="dark" name="w-colorscheme">
		                                        <label for="w-colorscheme-dark"><?php esc_attr_e( 'Dark', $this->plugin_name ); ?></label>
		                                    </div>
		                                </div>
		                            </div>
	
		                            <div class="col-lg-12 col-md-12 col-sm-12 col-sm-layout">
		                                <div class="base-margin-bottom">
		                                    <label><?php esc_attr_e( 'Layout', $this->plugin_name ); ?></label>
		                                    <div class="col-lg-12 js-fixed-size-buttons radio-buttons">
		                                        <div class="row">
		                                            <div class="col-lg-4 col-sm-2 col-xs-2  widget__various-width">
		                                                <input id="w-fixed-300x600" type="radio" value="xxl" name="w-proportion">
		                                                <label for="w-fixed-300x600">300x600</label>
		                                            </div>
		                                            <div class="col-lg-4 col-sm-2 col-xs-2  widget__various-width">
		                                                <input id="w-fixed-300x250" type="radio" value="m" name="w-proportion">
		                                                <label for="w-fixed-300x250">300x250</label>
		                                            </div>
	
		                                            <div class="col-lg-4 col-sm-2 col-xs-2  widget__various-width">
		                                                <input checked="" id="w-custom" type="radio" value="custom" name="w-proportion">
		                                                <label for="w-custom"><?php esc_attr_e( 'Custom', $this->plugin_name ); ?></label>
		                                            </div>
		                                        </div>
		                                    </div>
		                                    <div class="col-lg-12 js-tab-buttons radio-buttons">
		                                        <div class="row">
		                                            <div class="col-lg-12 line"></div>
		                                            <div class="col-lg-4 col-sm-2 col-xs-2  widget__various-width">
		                                                <input checked="" id="w-layout-vertical" type="radio" value="vertical" name="w-layout">
		                                                <label for="w-layout-vertical"><?php esc_attr_e( 'Vertical', $this->plugin_name ); ?></label>
		                                            </div>
		                                            <div class="col-lg-4 col-sm-2 col-xs-2  widget__various-width">
		                                                <input id="w-layout-horizontal" type="radio" value="horizontal" name="w-layout">
		                                                <label for="w-layout-horizontal"><?php esc_attr_e( 'Horizontal', $this->plugin_name ); ?></label>
		                                            </div>
		                                        </div>
		                                    </div>
		                                </div>
		                            </div>
	
		                        </div>
	
		                        <div class="row row-native">
		                            <div class="col-lg-12 js_widget_width_slider">
		                              <label for="w-width">
											<?php esc_attr_e( 'Width', $this->plugin_name ); ?> <span class="config_field__description"><?php esc_attr_e( '(px)', $this->plugin_name ); ?></span>
		                              </label>
		                              <div class="bootstrap_slider bootstrap_slider-horizontal">
		                                <input id="w-width" name="w-width" type="text" data-slider-min="350" data-slider-max="500" data-slider-step="1" data-slider-value="350">
		                              </div>
		                            </div>
		                            <div class="col-lg-12 double-margin-bottom">
		                              <label for="w-borderradius">
											<?php esc_attr_e( 'Corner Radius', $this->plugin_name ); ?> <span class="config_field__description"><?php esc_attr_e( '(px)', $this->plugin_name ); ?></span>
		                              </label>
		                              <div class="bootstrap_slider bootstrap_slider-horizontal">
		                                <input id="w-borderradius" name="w-borderradius" type="text" data-slider-min="0" data-slider-max="20" data-slider-step="1" data-slider-value="4">
		                              </div>
		                            </div>
		                        </div>
		                    </div>
	
		                    <div class="row row-native visible-lg">
		                        <div class="col-lg-6 col-md-3 col-sm-3">
		                            <button w-widget-type="event-discovery" type="button" class="js_get_widget_code btn btn-block button button-blue widget_config__btn"><?php esc_attr_e( 'ADD WIDGET', $this->plugin_name ); ?></button>
		                        </div>
		                        <div class="col-lg-6 col-md-3 col-sm-3">
		                            <button type="button" class="js_reset_widget btn btn-block button-white-gray-border widget_config__btn"><?php esc_attr_e( 'RESET', $this->plugin_name ); ?></button>
		                        </div>
		                    </div>
		                </div>
	
		            </form>
	
		        </div>
	
		        <div id="widget-constructor" class="col-lg-8 col-lg-widget">
		            <div class="widget-container-wrapper" data-min="350" data-max="1012" style="margin-top: 0px;">
		                <div class="widget-container widget-container--discovery">
		                    <div w-type="event-discovery" w-tmapikey="5QGCEXAsJowiCI4n1uAwMlCGAcSNAEmG" w-googleapikey="AIzaSyBQrJ5ECXDaXVlICIdUBOe8impKIGHDzdA" w-keyword="" w-theme="simple" w-colorscheme="light" w-width="350" w-height="600" w-size="25" w-border="0" w-borderradius="4" w-postalcode="90015" w-radius="25" w-country="US" w-period="week" w-layout="vertical" w-attractionid="" w-promoterid="" w-venueid="" w-affiliateid="" w-segmentid="" w-proportion="custom"></div>
		                </div>
		            </div>
		        </div>
		    </div>
		</div>
	</div>
</div>

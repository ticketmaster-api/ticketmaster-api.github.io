<?php
/**
 * Partial of the countdown widgets
 *
 * @link http://www.ticketmaster.com
 * @since 1.0.0
 *
 * @package Ticketmaster
 * @subpackage Ticketmaster/admin/partials
 */

?>

<div id="ticketmaster-settings" class="wrap">
	<h2><?php esc_attr_e( 'Ticketmaster Settings', $this->plugin_name ); ?></h2>
	<?php
	require_once( 'ticketmaster-admin-nav-tab.php' );
	?>

	<div class="wrap ticketmaster-metaboxes">
		<div id="calendar-config">
			<h2><?php esc_attr_e( 'Calendar Widget', $this->plugin_name ); ?></h2>
			<p><?php esc_attr_e( 'You can use the widget configurator below to customize the layout of the widget.', $this->plugin_name );?></p>
			<div class="row row-native">
				<div class="col-lg-4 config-block">

					<form accept-charset="UTF-8" class="main-widget-config-form common_tabs" method="post" autocomplete="off">

						<!--Use for mobile devices 'Go' button-->
						<button type="submit" class="hidden"></button>

						<div>
							<label for="w-title"><?php esc_attr_e( 'Title', $this->plugin_name ); ?> <span class="config_field__description"><?php esc_attr_e( '(Required)', $this->plugin_name ); ?></span></label>
							<input type="text" id="w-title" name="w-title" maxlength="255">
						</div>

						<ul class="nav nav-tabs" data-tabs="tabs">
							<li class="active">
								<a href="#widget-config-setup" data-toggle="tab"><?php esc_attr_e( 'Technical', $this->plugin_name ); ?></a>
							</li>
							<li>
								<a id="js_styling_nav_tab" href="#widget-config-styling" data-toggle="tab"><?php esc_attr_e( 'Visual', $this->plugin_name ); ?></a>
							</li>
						</ul>

						<div class="tab-content">
							<div class="tab-pane fade in active" id="widget-config-setup">
								<div class="row row-native">
									<div class="col-lg-12 col-md-6 col-sm-6">
										<div class="widget_api_key">
											<label for="w-tm-api-key">
												<?php esc_attr_e( 'API Key', $this->plugin_name ); ?> <span class="config_field__description"><?php esc_attr_e( '(Required)', $this->plugin_name ); ?></span>
											</label>
											<a href="https://developer-acct.ticketmaster.com/user/login" class="pull-right"><?php esc_attr_e( 'Get your own', $this->plugin_name ); ?></a>
											<div class="widget_api_key__field">
												<input type="text" id="w-tm-api-key" name="w-tm-api-key" value="5QGCEXAsJowiCI4n1uAwMlCGAcSNAEmG">
												<a href="http://developer.ticketmaster.com/support/faq/" class="widget_api_key__question"></a>
											</div>
										</div>
									</div>
									<div class="col-lg-12 col-md-6 col-sm-6">
										<label for="w-keyword"><?php esc_attr_e( 'Keyword', $this->plugin_name ); ?></label>
										<input type="text" id="w-keyword" name="w-keyword" value="">
									</div>
								</div>

								<div class="row row-native">
									<div class="col-lg-6 col-md-6 col-sm-3">
										<label for="w-postalcode"><?php esc_attr_e( 'ZIP Code', $this->plugin_name ); ?></label>
										<input type="text" id="w-postalcode" name="w-postalcode" value="90015">
									</div>
									<div class="col-lg-6 col-md-6 col-sm-3">
										<label for="w-radius">
											<?php esc_attr_e( 'Radius', $this->plugin_name ); ?> <span class="config_field__description"><?php esc_attr_e( '(miles)', $this->plugin_name ); ?></span>
										</label>
										<!-- <input class="js_widget__number js_numeric_input text-center" type="number" id="w-radius" name="w-radius" value="25"> -->

										<div class="js_custom_select custom_select">
											<select id="w-radius" class="custom_select__field" name="w-radius">
												<option selected value="25">25</option>
												<option value="15">15</option>
												<option value="5">5</option>
											</select>
											<?php /*
											<input class="custom_select__placeholder" type="number" min="0" value="25" readonly="" contenteditable="true">
											<ul class="custom_select__list js_widget_custom__list">
												<li class="custom_select__item" data-value="25">25</li>
												<li class="custom_select__item" data-value="15">15</li>
												<li class="custom_select__item" data-value="5">5</li>
											</ul>
											*/
											?>
										</div>

									</div>
								</div>
								<div class="row row-native">
									<div class="col-lg-12 col-md-12 col-sm-6">
										<label for="w-country"><?php esc_attr_e( 'Country', $this->plugin_name ); ?></label>
									</div>
									<div class="col-xs-12 country-select">
										<div class="js_custom_select custom_select">
											<select id="w-country" class="custom_select__field" name="w-country" disabled>
												<option selected value="US"><?php esc_attr_e( 'United States', $this->plugin_name ); ?></option>
											</select>
											<?php /*
											<input class="custom_select__placeholder" type="text" value="United States" readonly="">
											<ul class="custom_select__list js_widget_custom__list">
												<li class="custom_select__item" data-value="US"><?php esc_attr_e( 'United States', $this->plugin_name ); ?></li>
											</ul>
											*/ 
											?>
										</div>
									</div>
								</div>
							</div>

							<div class="tab-pane fade" id="widget-config-styling">
								<div class="row row-native">
									<div class="col-lg-12 col-md-12 col-sm-12 col-sm-color_scheme">
										<div class="widget__color_scheme_control">
											<label><?php esc_attr_e( 'Color Scheme', $this->plugin_name ); ?></label>
											<div class="tab-buttons">
												<input checked id="w-colorscheme-light" type="radio" value="light" name="w-colorscheme">
												<label for="w-colorscheme-light"><?php esc_attr_e( 'Light', $this->plugin_name ); ?></label>
												<input id="w-colorscheme-dark" type="radio" value="dark" name="w-colorscheme">
												<label for="w-colorscheme-dark"><?php esc_attr_e( 'Dark', $this->plugin_name ); ?></label>
											</div>
										</div>
									</div>

								</div>

								<div class="row row-native">
									<div class="col-lg-12 double-margin-bottom">
										<label for="w-borderradius">
											<?php esc_attr_e( 'Corner Radius', $this->plugin_name ); ?> <span class="config_field__description"><?php esc_attr_e( '(px)', $this->plugin_name ); ?></span>
										</label>
										<div class="bootstrap_slider bootstrap_slider-horizontal">
											<input id="w-borderradius" name="w-borderradius" type="text" data-slider-min="0" data-slider-max="20" data-slider-step="1" data-slider-value="4">
										</div>
									</div>

									<!--<div class="col-lg-12 base-margin">
									  <input type="checkbox" id="w-border">
									  <label for="w-border"><span></span>Include Border</label>
									</div>-->

								</div>
							</div>

							<div class="row row-native visible-lg">
								<div class="col-lg-6 col-md-3 col-sm-3">
									<button w-widget-type="calendar" type="button" class="js_get_widget_code btn btn-block button button-blue widget_config__btn"><?php esc_attr_e( 'ADD WIDGET', $this->plugin_name ); ?></button>
								</div>
								<div class="col-lg-6 col-md-3 col-sm-3">
									<button type="button" class="js_reset_widget btn btn-block button-white-gray-border widget_config__btn"><?php esc_attr_e( 'RESET', $this->plugin_name ); ?></button>
								</div>
							</div>
						</div>

					</form>

				</div>

				<div class="col-lg-8 col-lg-widget">
					<div class="widget-container-wrapper">
						<div class="widget-container widget-container--calendar">
							<script src="https://www.promisejs.org/polyfills/promise-6.1.0.min.js"></script>
							<div w-type="calendar" w-tmapikey="5QGCEXAsJowiCI4n1uAwMlCGAcSNAEmG" w-googleapikey="AIzaSyBQrJ5ECXDaXVlICIdUBOe8impKIGHDzdA" w-keyword="" w-theme="calendar" w-colorscheme="light" w-width="298" w-height="400" w-size="25" w-border="1" w-borderradius="4" w-postalcode="90015"  w-radius="25" w-country="US" w-latlong="34.0390107,-118.2672801" w-period="week" w-period-week="week" w-layout="vertical" w-classificationid="" w-attractionid="" w-promoterid="" w-venueid="" w-affiliateid="" w-segmentid="" w-proportion="standart"></div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>

(function( $ ) {
	'use strict';

	$(function() {
		var $widgetsList = document.querySelector('#widgets-list');

		$('span.delete-widget').live('click', function(){
			var item = $(this);
			var widget_id = item.data('widgetid');
			$.ajax({
				type: 'POST',
				url: ajaxurl,
				data: {
					action : 'delete_widget',
					id: widget_id
				},
				success: function (response) {
					var data = JSON.parse(response);
					if(data.error) {
						showModalDialog( data.status, translations.error_title );
					} else{
						item.parent().parent().hide('slow', function(){
							$(this).remove();

							if($widgetsList.childElementCount === 0) {
								var widgetListItem = document.createElement('p');
								widgetListItem.textContent = translations.empty_widgets_list_text_content;
								$widgetsList.appendChild(widgetListItem);
							}
						});
					}
				}
			});
		});

		$('#ticketmaster-settings #w-universe-modal-widget').change(function() {
			var state = (this.checked) ? 1 : 0;
			$.ajax({
				type: 'POST',
				url: ajaxurl,
				data: {
					action : 'change_universe_modal_widget_state',
					state : state
				}
			});
		});

		$('#ticketmaster-settings .js_get_widget_code').on('click', function(){
			var title = document.querySelector('input[name=w-title]'),
			    titleLabel = document.querySelector('[for=w-title]'), 
			    errorContainer = title.parentNode, 
			    container = document.createElement("div"),
			    apiCode = document.querySelector('input[name=w-tm-api-key]'),
				widget_type = $(this).attr('w-type'),
				widget_params = {};
			var widget = $('#' + widget_type + '-config div[w-type="' + widget_type + '"]').clone().children().remove().end().get(0);
			if(title.value.length === 0) {
                if (document.querySelector('.widget-title') === null) {
                  container.classList.add("widget-title");
                  container.classList.add("error-message");
                  container.innerHTML = 'Please enter widget title!';
                  errorContainer.appendChild(container);
                }
				titleLabel.classList.add('error');
				title.classList.add('error');
				title.focus();
				// showModalDialog( translations.empty_title_error_message, translations.error_title );
				return;
			}
			if(apiCode.value.length === 0){
				apiCode.classList.add('error');
				showModalDialog( 'API Key is empty', translations.error_title );
				return;
			}
			$.each(widget.attributes, function() {
				if(this.name.match(/^w-/)) {
					widget_params[this.name] = this.value;
				}
			});

			widget_params = JSON.stringify(widget_params);
			
			$.ajax({
				type: 'POST',
				url: ajaxurl,
				data: {
					action : 'create_widget',
					type: widget_type,
					title: title.value,
					params: widget_params
				},
				success: function (response) {
					var data = JSON.parse(response);
					if(data.error) {
						showModalDialog( data.status, translations.error_title );
					} else {
						title.classList.remove('error');
						titleLabel.classList.remove('error');
                        if (document.querySelector('.error-message') !== null) errorContainer.removeChild(document.querySelector('.error-message'));
						showModalDialog( data.status );
					}
				}
			});
		});

        $('#ticketmaster-settings .js_reset_widget').on('click', function(){
            var title = document.querySelector('input[name=w-title]'),
			    titleLabel = document.querySelector('[for=w-title]'), 
			    errorContainer = title.parentNode;
            title.classList.remove('error');
		    titleLabel.classList.remove('error');
            if (document.querySelector('.error-message') !== null) errorContainer.removeChild(document.querySelector('.error-message')); 
        });        	

	});

	function showModalDialog(msg, title){
		if (!title)
			title = translations.info_title;
		if (!msg)
			msg = translations.empty_message_text_content;
		$("<div></div>").html(msg).dialog({
			title: title,
			resizable: false,
			modal: true,
			closeOnEscape: true,
			buttons: {
				"Ok": function()
				{
					$( this ).dialog( "close" );
				}
			}
		});
	}

})( jQuery );

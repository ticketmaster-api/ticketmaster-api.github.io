(function( $ ) {
	'use strict';

	$(function() {
		var $widgetsList = document.querySelector('#widgets-list');

		$(".entry-content a[href*='universe']").live('click', function(e){
			window.location.href = this.getAttribute('href');
		});

	});	

})( jQuery );